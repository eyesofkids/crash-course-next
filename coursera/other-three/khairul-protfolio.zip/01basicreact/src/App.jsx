// App.jsx
import { useEffect, useRef, useState } from "react";
import "./App.css";

const projects = [
  {
    id: 1,
    title: "React Space",
    description:
      "Handy tool belt to create amazing AR components in a React app."
  },
  {
    id: 2,
    title: "React Infinite Scroll",
    description:
      "A scrollable bottom sheet with virtualization support and native animations."
  },
  {
    id: 3,
    title: "Photo Gallery",
    description:
      "A one-stop shop for photographers to share and monetize their photos."
  },
  {
    id: 4,
    title: "Event Planner",
    description:
      "A mobile application for leisure seekers to discover unique events."
  }
];

export default function App() {
  const [showHeader, setShowHeader] = useState(true);
  const [lastScrollY, setLastScrollY] = useState(0);

  const projectsRef = useRef(null);
  const contactRef = useRef(null);
  const topRef = useRef(null);

  const [formData, setFormData] = useState({
    name: "",
    email: "",
    type: "Freelance project proposal",
    message: ""
  });

  const [errors, setErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState("");

  // hide / show header on scroll
  useEffect(() => {
    const handleScroll = () => {
      const currentY = window.scrollY;

      if (currentY > lastScrollY + 10) {
        setShowHeader(false);
      } else if (currentY < lastScrollY - 10) {
        setShowHeader(true);
      }

      setLastScrollY(currentY);
    };

    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, [lastScrollY]);

  const scrollToSection = (ref) => {
    ref.current?.scrollIntoView({ behavior: "smooth" });
  };

  const validateForm = () => {
    const newErrors = {};

    if (!formData.name.trim()) newErrors.name = "Name is required";
    if (!formData.email.trim()) {
      newErrors.email = "Email is required";
    } else {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(formData.email)) {
        newErrors.email = "Please enter a valid email address";
      }
    }
    if (!formData.message.trim()) {
      newErrors.message = "Please enter a short message";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setSubmitStatus("");
    if (!validateForm()) return;

    setIsSubmitting(true);

    // fake async submit
    setTimeout(() => {
      setIsSubmitting(false);
      setSubmitStatus("Your message has been sent. Thank you!");
      setFormData({
        name: "",
        email: "",
        type: "Freelance project proposal",
        message: ""
      });
      setErrors({});
    }, 1200);
  };

  return (
    <div className="page" ref={topRef}>
      {/* HEADER */}
      <header className={`header ${showHeader ? "header--visible" : "header--hidden"}`}>
        <div className="header__left">
          <span className="logo">Pete</span>
        </div>

        <nav className="header__nav">
          {/* external links */}
          <a
            href="https://github.com/your-username"
            target="_blank"
            rel="noreferrer"
            aria-label="GitHub"
          >
            GitHub
          </a>
          <a
            href="https://www.linkedin.com/in/your-username"
            target="_blank"
            rel="noreferrer"
            aria-label="LinkedIn"
          >
            LinkedIn
          </a>
          <a
            href="mailto:you@example.com"
            aria-label="Email"
          >
            Email
          </a>
        </nav>

        {/* internal links */}
        <div className="header__links">
          <button onClick={() => scrollToSection(projectsRef)}>Projects</button>
          <button onClick={() => scrollToSection(contactRef)}>Contact Me</button>
        </div>
      </header>

      {/* HERO / LANDING */}
      <main>
        <section className="hero" aria-labelledby="hero-heading">
          <div className="hero__avatar-wrapper">
            <img
              className="hero__avatar"
              src="/avatar.png"
              alt="Pete's profile avatar"
            />
          </div>
          <p className="hero__intro">Hello, I am Pete!</p>
          <h1 id="hero-heading" className="hero__title">
            A frontend developer specialised in React
          </h1>
          <p className="hero__bio">
            Building responsive interfaces with React, JavaScript, and modern CSS.
          </p>
        </section>

        {/* PROJECTS */}
        <section className="projects" ref={projectsRef}>
          <h2 className="section-title">Featured Projects</h2>
          <div className="projects__grid">
            {projects.map((project) => (
              <article className="project-card" key={project.id}>
                <div className="project-card__image" aria-hidden="true" />
                <div className="project-card__body">
                  <h3 className="project-card__title">{project.title}</h3>
                  <p className="project-card__text">{project.description}</p>
                  <button
                    type="button"
                    className="project-card__button"
                    aria-label={`See more about ${project.title}`}
                  >
                    See more →
                  </button>
                </div>
              </article>
            ))}
          </div>
        </section>

        {/* CONTACT FORM */}
        <section className="contact" ref={contactRef}>
          <h2 className="section-title">Contact me</h2>
          <form className="contact__form" onSubmit={handleSubmit} noValidate>
            <label>
              Name
              <input
                name="name"
                type="text"
                value={formData.name}
                onChange={handleChange}
              />
              {errors.name && <span className="error">{errors.name}</span>}
            </label>

            <label>
              Email Address
              <input
                name="email"
                type="email"
                value={formData.email}
                onChange={handleChange}
              />
              {errors.email && <span className="error">{errors.email}</span>}
            </label>

            <label>
              Type of enquiry
              <select
                name="type"
                value={formData.type}
                onChange={handleChange}
              >
                <option>Freelance project proposal</option>
                <option>Full‑time opportunity</option>
                <option>General question</option>
              </select>
            </label>

            <label>
              Your message
              <textarea
                name="message"
                rows="5"
                value={formData.message}
                onChange={handleChange}
              />
              {errors.message && <span className="error">{errors.message}</span>}
            </label>

            <button type="submit" disabled={isSubmitting}>
              {isSubmitting ? "Submitting..." : "Submit"}
            </button>

            {submitStatus && (
              <p className="contact__status" role="status">
                {submitStatus}
              </p>
            )}
          </form>
        </section>
      </main>

      <footer className="footer">
        <button onClick={() => scrollToSection(topRef)}>Back to top</button>
        <span>Pete © 2022</span>
      </footer>
    </div>
  );
}
