import Header from './components/Header';
import Hero from './components/Hero';
import Projects from './components/Projects';
import ContactMe from './components/ContactMe';
import Footer from './components/Footer';

function App() {
  return (
    <div className="min-h-screen">
      <Header />
      <Hero />
      <Projects />
      <ContactMe />
      <Footer />
    </div>
  );
}

export default App;
