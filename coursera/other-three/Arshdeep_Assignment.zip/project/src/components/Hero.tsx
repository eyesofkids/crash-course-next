import { User } from 'lucide-react';

const Hero = () => {
  return (
    <section className="min-h-screen bg-gradient-to-br from-slate-700 via-slate-800 to-slate-900 text-white flex items-center justify-center pt-20">
      <div className="max-w-4xl mx-auto px-6 text-center">
        <div className="mb-8 flex justify-center">
          <div className="w-40 h-40 rounded-full bg-white flex items-center justify-center overflow-hidden shadow-2xl">
            <User size={80} className="text-slate-700" />
          </div>
        </div>

        <p className="text-lg mb-6 text-gray-300">Hello, I am Arshdeep Singh!</p>

        <h1 className="text-5xl md:text-6xl font-bold mb-6 leading-tight">
          A frontend developer
          <br />
          specialised in React
        </h1>

        <p className="text-xl text-gray-300 max-w-2xl mx-auto">
          Passionate about creating beautiful, responsive, and user-friendly web applications
          that make a difference.
        </p>
      </div>
    </section>
  );
};

export default Hero;
