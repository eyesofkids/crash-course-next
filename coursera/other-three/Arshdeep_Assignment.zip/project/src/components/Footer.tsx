const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-gray-900 text-gray-400 py-6">
      <div className="max-w-7xl mx-auto px-6 text-center">
        <p>Pete &copy; {currentYear}</p>
      </div>
    </footer>
  );
};

export default Footer;
