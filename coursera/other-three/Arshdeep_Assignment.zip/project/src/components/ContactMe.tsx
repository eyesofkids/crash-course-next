import { useState, FormEvent } from 'react';
import { supabase } from '../lib/supabase';

interface FormData {
  name: string;
  email: string;
  enquiryType: string;
  message: string;
}

interface FormErrors {
  name?: string;
  email?: string;
  enquiryType?: string;
  message?: string;
}

const ContactMe = () => {
  const [formData, setFormData] = useState<FormData>({
    name: '',
    email: '',
    enquiryType: '',
    message: '',
  });

  const [errors, setErrors] = useState<FormErrors>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState<'idle' | 'success' | 'error'>('idle');

  const validateForm = (): boolean => {
    const newErrors: FormErrors = {};

    if (!formData.name.trim()) {
      newErrors.name = 'Name is required';
    }

    if (!formData.email.trim()) {
      newErrors.email = 'Email is required';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = 'Please enter a valid email address';
    }

    if (!formData.enquiryType) {
      newErrors.enquiryType = 'Please select an enquiry type';
    }

    if (!formData.message.trim()) {
      newErrors.message = 'Message is required';
    } else if (formData.message.trim().length < 25) {
      newErrors.message = 'Message must be at least 25 characters';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setSubmitStatus('idle');

    if (!validateForm()) {
      return;
    }

    setIsSubmitting(true);

    try {
      const { error } = await supabase.from('contact_messages').insert([
        {
          name: formData.name.trim(),
          email: formData.email.trim(),
          enquiry_type: formData.enquiryType,
          message: formData.message.trim(),
        },
      ]);

      if (error) throw error;

      setSubmitStatus('success');
      setFormData({ name: '', email: '', enquiryType: '', message: '' });
      setErrors({});
    } catch (error) {
      console.error('Error submitting form:', error);
      setSubmitStatus('error');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    if (errors[name as keyof FormErrors]) {
      setErrors((prev) => ({ ...prev, [name]: undefined }));
    }
    setSubmitStatus('idle');
  };

  return (
    <section id="contact" className="bg-gradient-to-br from-violet-700 to-violet-900 py-20">
      <div className="max-w-2xl mx-auto px-6">
        <h2 className="text-4xl font-bold text-white mb-12 text-center">Contact me</h2>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label htmlFor="name" className="block text-white font-medium mb-2">
              Name
            </label>
            <input
              type="text"
              id="name"
              name="name"
              value={formData.name}
              onChange={handleChange}
              className={`w-full px-4 py-3 rounded-lg bg-violet-800 border-2 text-white placeholder-violet-300 focus:outline-none focus:border-violet-400 transition-colors ${
                errors.name ? 'border-red-400' : 'border-violet-700'
              }`}
              placeholder="Your name"
            />
            {errors.name && <p className="mt-2 text-red-300 text-sm">{errors.name}</p>}
          </div>

          <div>
            <label htmlFor="email" className="block text-white font-medium mb-2">
              Email Address
            </label>
            <input
              type="email"
              id="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              className={`w-full px-4 py-3 rounded-lg bg-violet-800 border-2 text-white placeholder-violet-300 focus:outline-none focus:border-violet-400 transition-colors ${
                errors.email ? 'border-red-400' : 'border-violet-700'
              }`}
              placeholder="your.email@example.com"
            />
            {errors.email && <p className="mt-2 text-red-300 text-sm">{errors.email}</p>}
          </div>

          <div>
            <label htmlFor="enquiryType" className="block text-white font-medium mb-2">
              Type of enquiry
            </label>
            <select
              id="enquiryType"
              name="enquiryType"
              value={formData.enquiryType}
              onChange={handleChange}
              className={`w-full px-4 py-3 rounded-lg bg-violet-800 border-2 text-white focus:outline-none focus:border-violet-400 transition-colors ${
                errors.enquiryType ? 'border-red-400' : 'border-violet-700'
              }`}
            >
              <option value="">Please select an enquiry</option>
              <option value="freelance">Freelance project proposal</option>
              <option value="job">Job opportunity</option>
              <option value="collaboration">Collaboration</option>
              <option value="other">Other</option>
            </select>
            {errors.enquiryType && (
              <p className="mt-2 text-red-300 text-sm">{errors.enquiryType}</p>
            )}
          </div>

          <div>
            <label htmlFor="message" className="block text-white font-medium mb-2">
              Your message
            </label>
            <textarea
              id="message"
              name="message"
              value={formData.message}
              onChange={handleChange}
              rows={6}
              className={`w-full px-4 py-3 rounded-lg bg-violet-800 border-2 text-white placeholder-violet-300 focus:outline-none focus:border-violet-400 transition-colors resize-none ${
                errors.message ? 'border-red-400' : 'border-violet-700'
              }`}
              placeholder="Type your message here..."
            />
            {errors.message && <p className="mt-2 text-red-300 text-sm">{errors.message}</p>}
          </div>

          {submitStatus === 'success' && (
            <div className="p-4 bg-green-500 text-white rounded-lg text-center font-medium">
              Message sent successfully! I'll get back to you soon.
            </div>
          )}

          {submitStatus === 'error' && (
            <div className="p-4 bg-red-500 text-white rounded-lg text-center font-medium">
              Failed to send message. Please try again.
            </div>
          )}

          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full py-3 bg-violet-600 hover:bg-violet-500 text-white font-semibold rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isSubmitting ? 'Submitting...' : 'Submit'}
          </button>
        </form>
      </div>
    </section>
  );
};

export default ContactMe;
